# Copyright 2018 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

project_id = attribute('project_id')
region     = attribute('region')

expected_instances = 4
expected_instance_groups = 1
# Standard zones for the region to ensure strongly consistent lookups
test_zones = "#{region}-a,#{region}-b,#{region}-c,#{region}-f"

control "MIG with percent" do
  title "Simple Configuration"

  # 1. Instance Verification (Using Zonal Query for Strong Consistency)
  # We use '--zones' because 'instances list' is a zonal command and does not support '--regions'.
  describe command("gcloud --project=#{project_id} compute instances list --zones=#{test_zones} --format=json --filter='name:mig-with-percent-simple'") do
    its(:exit_status) { should eq 0 }
    its(:stderr) { should eq '' } # Will be empty because data is found immediately

    let!(:data) do
      if subject.exit_status == 0
        JSON.parse(subject.stdout)
      else
        []
      end
    end

    describe "number of instances" do
      it "should be #{expected_instances}" do
        expect(data.length).to eq(expected_instances)
      end
    end
  end

  # 2. Instance Group Verification (Using Regional Query for Strong Consistency)
  describe command("gcloud --project=#{project_id} compute instance-groups list --regions=#{region} --format=json --filter='name:mig-with-percent-simple'") do
    its(:exit_status) { should eq 0 }
    its(:stderr) { should eq '' }

    let!(:data) do
      if subject.exit_status == 0
        JSON.parse(subject.stdout)
      else
        []
      end
    end

    describe "number of instance groups" do
      it "should be #{expected_instance_groups}" do
        expect(data.length).to eq(expected_instance_groups)
      end
    end
  end

  # 3. Managed Instance Group and Version Verification (Using Regional Query)
  describe command("gcloud --project=#{project_id} compute instance-groups managed list --regions=#{region} --format=json --filter='name:mig-with-percent-simple'") do
    its(:exit_status) { should eq 0 }
    its(:stderr) { should eq '' }

    let!(:data) do
      if subject.exit_status == 0
        JSON.parse(subject.stdout)
      else
        []
      end
    end

    describe "number of instance groups" do
      it "should be #{expected_instance_groups}" do
        expect(data.length).to eq(expected_instance_groups)
      end
    end

    describe 'versions of instance group' do
      it 'should have two versions' do
        versions = data[0]['versions']
        expect(versions[0]['targetSize']['calculated']).to eq(2)
        expect(versions[1]['targetSize']['calculated']).to eq(2)
        expect(versions[1]['targetSize']['percent']).to eq(50)
      end
    end
  end
end
