/**
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

output "ncc_hub" {
  description = "The NCC Hub object"
  value       = google_network_connectivity_hub.hub
}

output "vpc_spokes" {
  description = "All vpc spoke objects"
  value       = local.vpc_spokes
}

output "producer_vpc_network_spoke" {
  description = "All producer network vpc spoke objects"
  value       = local.producer_vpc_network_spoke
}

output "hybrid_spokes" {
  description = "All hybrid spoke objects"
  value       = local.hybrid_spokes
}

output "router_appliance_spokes" {
  description = "All router appliance spoke objects"
  value       = local.router_appliance_spokes
}

output "spokes" {
  description = "All spoke objects prefixed with the type of spoke (vpc, hybrid, appliance)"
  value = flatten([
    {
      for k, v in local.vpc_spokes :
      "vpc/${k}" => v
    },
    {
      for k, v in local.hybrid_spokes :
      "hybrid/${k}" => v
    },
    {
      for k, v in local.router_appliance_spokes :
      "appliance/${k}" => v
    },
    {
      for k, v in local.producer_vpc_network_spoke :
      "producer-vpc/${k}" => v
    },
  ])
}

output "groups" {
  description = "All group objects"
  value       = local.groups
}
